<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv='refresh' content ='3; url=home.php'>
		</head>
		<body>
<div style="
    height: 200px;
    width: 400px;

    position: fixed;
    top: 50%;
    left: 50%;
    margin-top: -100px;
    margin-left: -200px;">
	<img src="images/wds.png"/>
	<h1> Welcome to SGBIT Training and placement cell</h1>
	<h3> Advancing Placements </h3>
	<h4> Please Wait While we Redirect you to our Page </h4>
	<h6> Not Redirected?? <a href="home.php">Click Here</a></h6>
	</div>
	</body>
	</html>
